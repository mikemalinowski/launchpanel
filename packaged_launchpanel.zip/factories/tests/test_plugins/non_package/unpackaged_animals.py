from factories.examples.zoo import Animal


class Koala(Animal):
    species = 'koala'
